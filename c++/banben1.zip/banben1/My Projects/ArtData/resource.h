//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ArtData.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_NEWFILE_SAVE                102
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME1                  128
#define IDR_ARTDATTYPE                  129
#define IDD_CARDDLG                     130
#define IDD_ANALYSIS                    133
#define IDD_DIALOG1                     136
#define IDB_BITMAP1                     137
#define IDI_ICON1                       138
#define IDI_ICON3                       140
#define IDI_ICON4                       141
#define IDI_ICON5                       142
#define IDI_ICON2                       143
#define IDI_ICON6                       144
#define IDR_TOOLBAR1                    145
#define IDD_ANALYSIS2                   147
#define IDD_DATA_SAVE                   151
#define IDD_CLRDAT                      152
#define IDI_ICON7                       153
#define IDC_SIGNL_GAIN                  1000
#define IDC_SIGNL_GRND                  1001
#define IDC_SIGNL_RNG                   1002
#define IDC_COMBO1                      1005
#define IDC_COMBO2                      1006
#define IDC_SMPL_TIME                   1007
#define IDC_FST_CHNNL                   1008
#define IDC_LST_CHNNL                   1009
#define IDC_COMBO3                      1010
#define IDC_SMPL_FRQ                    1011
#define IDC_LIST2                       1016
#define IDC_BUTTON1                     1017
#define IDC_IMAGE2                      1024
#define IDC_EDIT_FFT                    1029
#define IDC_EDIT2                       1030
#define IDC_DATASEG                     1030
#define IDC_EDIT3                       1031
#define IDC_ANALTYPE                    1031
#define IDC_EDIT4                       1032
#define IDC_DATASEG2                    1032
#define IDC_EDIT5                       1033
#define IDM_SMPL_STOP                   32777
#define IDM_SMPL_START                  32779
#define IDM_SMPL_DISPLAY                32781
#define IDM_SMPL_PARM                   32782
#define IDM_SMPL_RESET                  32784
#define IDM_ANALSYS_GEN                 32785
#define IDM_ANALYSIS_REL                32786
#define ID_MENUITEM32787                32787
#define ID_KEY_CTLLEFT                  32788
#define ID_CTLLEFT                      32789
#define IDM_WRITETXT                    32791
#define IDM_CLEAR                       32792

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        154
#define _APS_NEXT_COMMAND_VALUE         32798
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
